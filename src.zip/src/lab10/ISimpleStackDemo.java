package lab10;

public class ISimpleStackDemo {

}
