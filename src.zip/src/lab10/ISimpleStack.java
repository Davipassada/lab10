package lab10;

public class ISimpleStack {
	
	void push(char c);
	char pop();
	boolean isEmpty();
	boolean isFull();
	void reset();
	char peek();
	int size();
}
