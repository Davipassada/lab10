public class ContaCorrente extends Conta {

	public ContaCorrente(int numeroConta, int numeroCartao, Cliente cliente, int senha, double saldo) {
		super(numeroConta, numeroCartao, cliente, senha, saldo);
	}

}
